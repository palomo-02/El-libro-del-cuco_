package com.example.ellibrodelcuco.utils;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class RachaHelper {

    public static void actualizarRacha(String uid, FirebaseFirestore db) {
        db.collection("usuarios").document(uid).get()
            .addOnSuccessListener(doc -> {
                long rachaActual = 1;
                long rachaMaxima = 1;

                if (doc.exists()) {
                    Long ra = doc.getLong("rachaActual");
                    Long rm = doc.getLong("rachaMaxima");
                    if (ra != null) rachaActual = ra;
                    if (rm != null) rachaMaxima = rm;

                    Date ultimaActividad = doc.getDate("ultimaActividad");

                    if (ultimaActividad != null) {
                        Calendar hoy = Calendar.getInstance();
                        Calendar ultima = Calendar.getInstance();
                        ultima.setTime(ultimaActividad);

                        hoy.set(Calendar.HOUR_OF_DAY, 0);
                        hoy.set(Calendar.MINUTE, 0);
                        hoy.set(Calendar.SECOND, 0);
                        hoy.set(Calendar.MILLISECOND, 0);

                        ultima.set(Calendar.HOUR_OF_DAY, 0);
                        ultima.set(Calendar.MINUTE, 0);
                        ultima.set(Calendar.SECOND, 0);
                        ultima.set(Calendar.MILLISECOND, 0);

                        long diffDias = (hoy.getTimeInMillis() - ultima.getTimeInMillis()) / (1000 * 60 * 60 * 24);

                        if (diffDias == 0) {
                            guardar(uid, db, rachaActual, rachaMaxima);
                            return;
                        } else if (diffDias == 1) {
                            rachaActual = rachaActual + 1;
                        } else {
                            rachaActual = 1;
                        }
                    }
                }

                if (rachaActual > rachaMaxima) rachaMaxima = rachaActual;
                guardar(uid, db, rachaActual, rachaMaxima);
            });
    }

    private static void guardar(String uid, FirebaseFirestore db, long rachaActual, long rachaMaxima) {
        Map<String, Object> datos = new HashMap<>();
        datos.put("rachaActual", rachaActual);
        datos.put("rachaMaxima", rachaMaxima);
        datos.put("ultimaActividad", new Date());
        db.collection("usuarios").document(uid).set(datos, com.google.firebase.firestore.SetOptions.merge());
    }
}
