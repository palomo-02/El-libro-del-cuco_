package com.example.ellibrodelcuco.interfaz_usuario.ACTIVITIES;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ellibrodelcuco.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPass, etPassConfirm;
    private MaterialButton btnRegister;
    private TextView tvGoLogin;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Ocultar barra superior
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        mAuth = FirebaseAuth.getInstance();


        etEmail = findViewById(R.id.etEmailReg);
        etPass = findViewById(R.id.etPassReg);
        etPassConfirm = findViewById(R.id.etPassConfirm);
        btnRegister = findViewById(R.id.btnRegister);
        tvGoLogin = findViewById(R.id.tvGoLogin);

        // BOTÓN REGISTRARSE
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String pass = etPass.getText().toString().trim();
                String confirm = etPassConfirm.getText().toString().trim();

                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
                    Toast.makeText(RegisterActivity.this, "Rellena todos los campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!pass.equals(confirm)) {
                    etPassConfirm.setError("Las contraseñas no coinciden");
                    return;
                }

                if (pass.length() < 6) {
                    etPass.setError("La contraseña debe tener al menos 6 caracteres");
                    return;
                }

                crearUsuarioFirebase(email, pass);
            }
        });

        // BOTÓN VOLVER AL LOGIN
        tvGoLogin.setOnClickListener(v -> {
            finish(); // Simplemente cierra esta pantalla y vuelve a la anterior (Login)
        });
    }

    private void crearUsuarioFirebase(String email, String pass) {
        Toast.makeText(this, "Creando cuenta...", Toast.LENGTH_SHORT).show();

        mAuth.createUserWithEmailAndPassword(email, pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // ÉXITO
                            Toast.makeText(RegisterActivity.this, "¡Cuenta creada!", Toast.LENGTH_LONG).show();
                            FirebaseUser user = mAuth.getCurrentUser();

                            // Vamos directos a la pantalla principal
                            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                            // Limpiamos el historial para que no pueda volver atrás al registro
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            finish();
                        } else {
                            // ERROR
                            Toast.makeText(RegisterActivity.this, "Fallo: " + task.getException().getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
}



