package com.example.ellibrodelcuco.interfaz_usuario.FRAGMENTS;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ellibrodelcuco.R;
import com.example.ellibrodelcuco.interfaz_usuario.ACTIVITIES.DetalleLibroActivity;
import com.example.ellibrodelcuco.interfaz_usuario.ADAPTERS.LibroAdapter;
import com.example.ellibrodelcuco.modelo.Libro;
import com.example.ellibrodelcuco.utils.LogrosHelper;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class perfil extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 101;

    private RecyclerView rvBiblioteca;
    private LibroAdapter libroAdapter;
    private List<Libro> listaLibrosFull, listaLibrosFiltrada;
    private TextView tvUserName, tvUserEmail, tvCountLeidos, tvLogroActual, tvRacha;
    private Button btnCerrarSesion;
    private ImageView ivProfilePic;
    private TabLayout tabLayout;
    private ChipGroup chipGroupLogros;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private FirebaseStorage storage;
    private String categoriaActual = "Pendiente";

    private static final Map<String, String> LOGROS_NOMBRES = new HashMap<String, String>() {{
        put(LogrosHelper.PRIMER_LIBRO, "📖 Primer libro");
        put(LogrosHelper.APRENDIZ, "🎓 Aprendiz");
        put(LogrosHelper.LECTOR, "📚 Lector");
        put(LogrosHelper.BIBLIOFILO, "🏛️ Bibliófilo");
        put(LogrosHelper.PRIMERA_RESENA, "✍️ Primera reseña");
        put(LogrosHelper.RACHA_7, "🔥 Racha 7 días");
        put(LogrosHelper.EXPLORADOR, "🌍 Explorador");
    }};

    private static final List<String> TODOS_LOGROS = new ArrayList<String>() {{
        add(LogrosHelper.PRIMER_LIBRO);
        add(LogrosHelper.APRENDIZ);
        add(LogrosHelper.LECTOR);
        add(LogrosHelper.BIBLIOFILO);
        add(LogrosHelper.PRIMERA_RESENA);
        add(LogrosHelper.RACHA_7);
        add(LogrosHelper.EXPLORADOR);
    }};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_perfil, container, false);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();

        tvUserName = view.findViewById(R.id.tvUserName);
        tvUserEmail = view.findViewById(R.id.tvUserEmail);
        tvCountLeidos = view.findViewById(R.id.tvCountLeidos);
        tvLogroActual = view.findViewById(R.id.tvLogroActual);
        tvRacha = view.findViewById(R.id.tvRacha);
        ivProfilePic = view.findViewById(R.id.ivProfilePic);
        rvBiblioteca = view.findViewById(R.id.rvBiblioteca);
        tabLayout = view.findViewById(R.id.tabLayoutCategorias);
        chipGroupLogros = view.findViewById(R.id.chipGroupLogros);
        btnCerrarSesion = view.findViewById(R.id.btnCerrarSesion);

        if (user != null) {
            tvUserEmail.setText(user.getEmail());
            tvUserName.setText(user.getDisplayName() != null && !user.getDisplayName().isEmpty()
                ? user.getDisplayName() : "Lector Cuco");
        }

        btnCerrarSesion.setOnClickListener(v -> {
            mAuth.signOut();
            Intent intent = new Intent(getContext(), com.example.ellibrodelcuco.interfaz_usuario.ACTIVITIES.LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });

        ivProfilePic.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_IMAGE_REQUEST);
        });

        listaLibrosFull = new ArrayList<>();
        listaLibrosFiltrada = new ArrayList<>();
        rvBiblioteca.setLayoutManager(new LinearLayoutManager(getContext()));
        libroAdapter = new LibroAdapter(listaLibrosFiltrada, libro -> {
            Intent intent = new Intent(getContext(), DetalleLibroActivity.class);
            intent.putExtra("libro", libro);
            startActivity(intent);
        });
        rvBiblioteca.setAdapter(libroAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                categoriaActual = tab.getText().toString();
                filtrarLibros();
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        if (user != null) {
            cargarDatos(user.getUid());
            cargarRacha(user.getUid());
            cargarAvatar(user.getUid());
            cargarLogros(user.getUid());
        }

        return view;
    }

    private void cargarDatos(String userId) {
        db.collection("usuarios").document(userId).collection("biblioteca")
            .addSnapshotListener((value, error) -> {
                if (value != null) {
                    listaLibrosFull.clear();
                    int leidosCount = 0;
                    for (QueryDocumentSnapshot doc : value) {
                        Libro libro = doc.toObject(Libro.class);
                        listaLibrosFull.add(libro);
                        if ("Leído".equalsIgnoreCase(libro.getEstado())) leidosCount++;
                    }
                    actualizarEstadisticas(leidosCount);
                    filtrarLibros();
                }
            });
    }

    private void cargarRacha(String userId) {
        db.collection("usuarios").document(userId)
            .addSnapshotListener((doc, error) -> {
                if (doc != null && doc.exists()) {
                    Long racha = doc.getLong("rachaActual");
                    if (racha != null && tvRacha != null) {
                        tvRacha.setText("🔥 " + racha + " días");
                    }
                }
            });
    }

    private void cargarAvatar(String userId) {
        db.collection("usuarios").document(userId).get()
            .addOnSuccessListener(doc -> {
                if (doc.exists()) {
                    String fotoUrl = doc.getString("fotoUrl");
                    if (fotoUrl != null && !fotoUrl.isEmpty() && ivProfilePic != null) {
                        Picasso.get().load(fotoUrl).into(ivProfilePic);
                    }
                }
            });
    }

    private void cargarLogros(String userId) {
        db.collection("usuarios").document(userId).collection("logros")
            .addSnapshotListener((value, error) -> {
                if (value == null || chipGroupLogros == null) return;
                List<String> desbloqueados = new ArrayList<>();
                for (QueryDocumentSnapshot doc : value) {
                    desbloqueados.add(doc.getId());
                }
                chipGroupLogros.removeAllViews();
                for (String logroId : TODOS_LOGROS) {
                    Chip chip = new Chip(getContext());
                    chip.setText(LOGROS_NOMBRES.containsKey(logroId) ? LOGROS_NOMBRES.get(logroId) : logroId);
                    chip.setClickable(false);
                    if (desbloqueados.contains(logroId)) {
                        chip.setChipBackgroundColorResource(com.google.android.material.R.color.design_default_color_primary);
                        chip.setTextColor(getResources().getColor(android.R.color.white, null));
                    } else {
                        chip.setChipBackgroundColorResource(android.R.color.darker_gray);
                        chip.setTextColor(getResources().getColor(android.R.color.white, null));
                        chip.setAlpha(0.5f);
                    }
                    chipGroupLogros.addView(chip);
                }
            });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            FirebaseUser user = mAuth.getCurrentUser();
            if (user == null) return;
            StorageReference ref = storage.getReference().child("avatares/" + user.getUid() + ".jpg");
            ref.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> ref.getDownloadUrl()
                    .addOnSuccessListener(uri -> {
                        String downloadUrl = uri.toString();
                        db.collection("usuarios").document(user.getUid())
                            .update("fotoUrl", downloadUrl)
                            .addOnSuccessListener(aVoid -> {
                                Picasso.get().load(downloadUrl).into(ivProfilePic);
                                Toast.makeText(getContext(), "Foto actualizada", Toast.LENGTH_SHORT).show();
                            });
                    }))
                .addOnFailureListener(e -> Toast.makeText(getContext(), "Error al subir la foto", Toast.LENGTH_SHORT).show());
        }
    }

    private void actualizarEstadisticas(int count) {
        if (tvCountLeidos != null) tvCountLeidos.setText(String.valueOf(count));
        String rango = "Novato";
        if (count >= 50) rango = "Erudito";
        else if (count >= 20) rango = "Bibliófilo";
        else if (count >= 10) rango = "Lector";
        else if (count >= 5) rango = "Aprendiz";
        if (tvLogroActual != null) tvLogroActual.setText(rango);
    }

    private void filtrarLibros() {
        listaLibrosFiltrada.clear();
        for (Libro l : listaLibrosFull) {
            if (l.getEstado() != null && l.getEstado().equalsIgnoreCase(categoriaActual)) {
                listaLibrosFiltrada.add(l);
            }
        }
        libroAdapter.notifyDataSetChanged();
    }
}