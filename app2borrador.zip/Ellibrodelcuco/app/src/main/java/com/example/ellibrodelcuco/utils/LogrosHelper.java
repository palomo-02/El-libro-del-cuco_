package com.example.ellibrodelcuco.utils;

import android.content.Context;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class LogrosHelper {

    public static final String PRIMER_LIBRO = "primer_libro";
    public static final String APRENDIZ = "aprendiz";
    public static final String LECTOR = "lector";
    public static final String BIBLIOFILO = "bibliofilo";
    public static final String PRIMERA_RESENA = "primera_resena";
    public static final String RACHA_7 = "racha_7";
    public static final String EXPLORADOR = "explorador";

    private static final Map<String, String> NOMBRES = new HashMap<String, String>() {{
        put(PRIMER_LIBRO, "Primer libro");
        put(APRENDIZ, "Aprendiz");
        put(LECTOR, "Lector");
        put(BIBLIOFILO, "Bibliófilo");
        put(PRIMERA_RESENA, "Primera reseña");
        put(RACHA_7, "Racha de 7 días");
        put(EXPLORADOR, "Explorador");
    }};

    public static void comprobar(String uid, FirebaseFirestore db, Context ctx) {
        db.collection("usuarios").document(uid).collection("logros").get()
            .addOnSuccessListener(logrosSnap -> {
                Set<String> yaDesbloqueados = new HashSet<>();
                for (QueryDocumentSnapshot d : logrosSnap) {
                    yaDesbloqueados.add(d.getId());
                }

                db.collection("usuarios").document(uid).collection("biblioteca").get()
                    .addOnSuccessListener(bibSnap -> {
                        int leidosCount = 0;
                        Set<String> generos = new HashSet<>();
                        for (QueryDocumentSnapshot d : bibSnap) {
                            String estado = d.getString("estado");
                            String genero = d.getString("genero");
                            if ("Leído".equalsIgnoreCase(estado)) leidosCount++;
                            if (genero != null && !genero.isEmpty()) generos.add(genero);
                        }

                        final int leidos = leidosCount;
                        final int generosDistintos = generos.size();

                        db.collection("usuarios").document(uid).get()
                            .addOnSuccessListener(userDoc -> {
                                long racha = 0;
                                if (userDoc.exists() && userDoc.getLong("rachaActual") != null) {
                                    racha = userDoc.getLong("rachaActual");
                                }
                                final long rachaFinal = racha;

                                Map<String, Boolean> candidatos = new HashMap<>();
                                if (leidos >= 1) candidatos.put(PRIMER_LIBRO, true);
                                if (leidos >= 5) candidatos.put(APRENDIZ, true);
                                if (leidos >= 10) candidatos.put(LECTOR, true);
                                if (leidos >= 50) candidatos.put(BIBLIOFILO, true);
                                if (rachaFinal >= 7) candidatos.put(RACHA_7, true);
                                if (generosDistintos >= 5) candidatos.put(EXPLORADOR, true);

                                for (Map.Entry<String, Boolean> entry : candidatos.entrySet()) {
                                    String logroId = entry.getKey();
                                    if (!yaDesbloqueados.contains(logroId)) {
                                        desbloquear(uid, db, ctx, logroId);
                                    }
                                }
                            });
                    });
            });
    }

    public static void comprobarResena(String uid, FirebaseFirestore db, Context ctx) {
        db.collection("usuarios").document(uid).collection("logros").document(PRIMERA_RESENA).get()
            .addOnSuccessListener(doc -> {
                if (!doc.exists()) {
                    desbloquear(uid, db, ctx, PRIMERA_RESENA);
                }
            });
    }

    private static void desbloquear(String uid, FirebaseFirestore db, Context ctx, String logroId) {
        Map<String, Object> datos = new HashMap<>();
        datos.put("desbloqueado", true);
        datos.put("fecha", new Date());
        db.collection("usuarios").document(uid).collection("logros").document(logroId)
            .set(datos)
            .addOnSuccessListener(aVoid -> {
                if (ctx instanceof android.app.Activity) {
                    android.view.View rootView = ((android.app.Activity) ctx).getWindow().getDecorView().getRootView();
                    String nombre = NOMBRES.containsKey(logroId) ? NOMBRES.get(logroId) : logroId;
                    Snackbar.make(rootView, "¡Logro desbloqueado: " + nombre + "!", Snackbar.LENGTH_LONG).show();
                }
            });
    }
}
