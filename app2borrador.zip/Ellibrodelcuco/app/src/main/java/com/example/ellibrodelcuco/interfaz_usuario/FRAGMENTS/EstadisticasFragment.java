package com.example.ellibrodelcuco.interfaz_usuario.FRAGMENTS;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.ellibrodelcuco.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EstadisticasFragment extends Fragment {

    private TextView tvTotalLeidos, tvTotalPaginas, tvMediaValoraciones, tvGeneroFavorito;
    private BarChart barChart;
    private PieChart pieChart;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_estadisticas, container, false);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        tvTotalLeidos = view.findViewById(R.id.tvTotalLeidos);
        tvTotalPaginas = view.findViewById(R.id.tvTotalPaginas);
        tvMediaValoraciones = view.findViewById(R.id.tvMediaValoraciones);
        tvGeneroFavorito = view.findViewById(R.id.tvGeneroFavorito);
        barChart = view.findViewById(R.id.barChart);
        pieChart = view.findViewById(R.id.pieChart);

        configurarGraficas();

        if (mAuth.getCurrentUser() != null) {
            cargarEstadisticas(mAuth.getCurrentUser().getUid());
        }

        return view;
    }

    private void configurarGraficas() {
        barChart.getDescription().setEnabled(false);
        barChart.setDrawGridBackground(false);
        barChart.setDrawBarShadow(false);
        barChart.getAxisRight().setEnabled(false);
        barChart.getAxisLeft().setAxisMinimum(0f);
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getXAxis().setGranularity(1f);
        barChart.animateY(800);

        pieChart.getDescription().setEnabled(false);
        pieChart.setUsePercentValues(true);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.TRANSPARENT);
        pieChart.setHoleRadius(35f);
        pieChart.setTransparentCircleRadius(40f);
        pieChart.animateY(800);
    }

    private void cargarEstadisticas(String uid) {
        db.collection("usuarios").document(uid).collection("biblioteca")
            .get()
            .addOnSuccessListener(snap -> {
                int totalLeidos = 0;
                int totalPaginas = 0;
                Map<String, Integer> generoCount = new HashMap<>();
                Map<Integer, Integer> librosPorMes = new HashMap<>();

                Calendar hace6Meses = Calendar.getInstance();
                hace6Meses.add(Calendar.MONTH, -5);
                hace6Meses.set(Calendar.DAY_OF_MONTH, 1);

                for (QueryDocumentSnapshot doc : snap) {
                    String estado = doc.getString("estado");
                    String genero = doc.getString("genero");
                    Long paginas = doc.getLong("totalPaginas");
                    Date fechaLeido = doc.getDate("fechaLeido");

                    if ("Leído".equalsIgnoreCase(estado)) {
                        totalLeidos++;
                        if (paginas != null) totalPaginas += paginas.intValue();
                        if (fechaLeido != null && !fechaLeido.before(hace6Meses.getTime())) {
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(fechaLeido);
                            int mes = cal.get(Calendar.MONTH);
                            librosPorMes.put(mes, librosPorMes.getOrDefault(mes, 0) + 1);
                        }
                    }

                    if (genero != null && !genero.isEmpty()) {
                        generoCount.put(genero, generoCount.getOrDefault(genero, 0) + 1);
                    }
                }

                tvTotalLeidos.setText(String.valueOf(totalLeidos));
                tvTotalPaginas.setText(String.valueOf(totalPaginas));

                String generoFav = "—";
                int maxGenero = 0;
                for (Map.Entry<String, Integer> e : generoCount.entrySet()) {
                    if (e.getValue() > maxGenero) {
                        maxGenero = e.getValue();
                        generoFav = e.getKey();
                    }
                }
                tvGeneroFavorito.setText(generoFav);

                actualizarBarChart(librosPorMes);
                actualizarPieChart(generoCount);
                cargarMediaValoraciones(uid);
            });
    }

    private void actualizarBarChart(Map<Integer, Integer> librosPorMes) {
        Calendar cal = Calendar.getInstance();
        List<BarEntry> entradas = new ArrayList<>();
        String[] etiquetas = new String[6];
        String[] nombresMeses = {"Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"};

        for (int i = 5; i >= 0; i--) {
            Calendar temp = Calendar.getInstance();
            temp.add(Calendar.MONTH, -i);
            int mes = temp.get(Calendar.MONTH);
            int idx = 5 - i;
            entradas.add(new BarEntry(idx, librosPorMes.getOrDefault(mes, 0)));
            etiquetas[idx] = nombresMeses[mes];
        }

        BarDataSet dataSet = new BarDataSet(entradas, "Libros leídos");
        dataSet.setColor(Color.parseColor("#4CAF50"));
        dataSet.setValueTextColor(Color.BLACK);

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.7f);
        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(etiquetas));
        barChart.setData(data);
        barChart.invalidate();
    }

    private void actualizarPieChart(Map<String, Integer> generoCount) {
        if (generoCount.isEmpty()) return;
        List<PieEntry> entradas = new ArrayList<>();
        for (Map.Entry<String, Integer> e : generoCount.entrySet()) {
            entradas.add(new PieEntry(e.getValue(), e.getKey()));
        }
        PieDataSet dataSet = new PieDataSet(entradas, "");
        dataSet.setColors(new int[]{
            Color.parseColor("#4CAF50"), Color.parseColor("#2196F3"),
            Color.parseColor("#FF9800"), Color.parseColor("#9C27B0"),
            Color.parseColor("#F44336"), Color.parseColor("#00BCD4")
        });
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueTextSize(11f);
        pieChart.setData(new PieData(dataSet));
        pieChart.invalidate();
    }

    private void cargarMediaValoraciones(String uid) {
        db.collection("usuarios").document(uid).collection("biblioteca")
            .get()
            .addOnSuccessListener(snap -> {
                final int[] totalResenas = {0};
                final float[] sumaNotas = {0f};
                final int[] pendiente = {snap.size()};

                if (snap.isEmpty()) {
                    tvMediaValoraciones.setText("—");
                    return;
                }

                for (QueryDocumentSnapshot doc : snap) {
                    doc.getReference().collection("resenas").get()
                        .addOnSuccessListener(resenasSnap -> {
                            for (QueryDocumentSnapshot r : resenasSnap) {
                                Double nota = r.getDouble("nota");
                                if (nota != null) {
                                    sumaNotas[0] += nota.floatValue();
                                    totalResenas[0]++;
                                }
                            }
                            pendiente[0]--;
                            if (pendiente[0] == 0) {
                                if (totalResenas[0] > 0) {
                                    tvMediaValoraciones.setText(String.format("%.1f", sumaNotas[0] / totalResenas[0]));
                                } else {
                                    tvMediaValoraciones.setText("—");
                                }
                            }
                        });
                }
            });
    }
}
