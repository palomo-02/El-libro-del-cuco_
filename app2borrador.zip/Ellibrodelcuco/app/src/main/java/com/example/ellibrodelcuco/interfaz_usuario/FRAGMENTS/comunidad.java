package com.example.ellibrodelcuco.interfaz_usuario.FRAGMENTS;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.ellibrodelcuco.R;

public class comunidad extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Asegúrate de haber creado el archivo res/layout/fragment_comunidad.xml
        return inflater.inflate(R.layout.fragment_comunidad, container, false);
    }
}