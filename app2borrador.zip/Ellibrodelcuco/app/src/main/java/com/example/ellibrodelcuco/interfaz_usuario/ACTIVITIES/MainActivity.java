package com.example.ellibrodelcuco.interfaz_usuario.ACTIVITIES;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.example.ellibrodelcuco.R;
import com.example.ellibrodelcuco.interfaz_usuario.FRAGMENTS.EstadisticasFragment;
import com.example.ellibrodelcuco.interfaz_usuario.FRAGMENTS.buscarLibros;
import com.example.ellibrodelcuco.interfaz_usuario.FRAGMENTS.comunidad;
import com.example.ellibrodelcuco.interfaz_usuario.FRAGMENTS.perfil;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new buscarLibros())
                    .commit();
        }

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int id = item.getItemId();

            if (id == R.id.nav_inicio) {
                selectedFragment = new buscarLibros();
            } else if (id == R.id.nav_comunidad) {
                selectedFragment = new comunidad();
            } else if (id == R.id.nav_estadisticas) {
                selectedFragment = new EstadisticasFragment();
            } else if (id == R.id.nav_perfil) {
                selectedFragment = new perfil();
            }

            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, selectedFragment)
                        .commit();
                return true;
            }
            return false;
        });
    }
}