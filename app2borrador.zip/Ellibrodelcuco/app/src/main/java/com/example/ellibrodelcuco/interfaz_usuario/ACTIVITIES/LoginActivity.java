package com.example.ellibrodelcuco.interfaz_usuario.ACTIVITIES;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ellibrodelcuco.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    // 1. Declarar variables para los elementos de la pantalla
    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin;
    private TextView tvRegister;

    // 2. Declarar la variable de Firebase Auth
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Ocultar la barra superior para que quede más limpio
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // 3. Inicializar Firebase (¡Importante!)
        mAuth = FirebaseAuth.getInstance();

        // 4. Enlazar variables con los IDs del XML
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);

        // 5. Configurar el botón de Iniciar Sesión
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();

                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                    Toast.makeText(LoginActivity.this, "Por favor, rellena todos los campos", Toast.LENGTH_SHORT)
                            .show();
                } else {
                    // Llamamos a la función que conecta con Firebase
                    iniciarSesionFirebase(email, password);
                }
            }
        });

        // 6. Configurar el botón de "Regístrate" (Por ahora solo muestra un mensaje)
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(LoginActivity.this, "Aquí iremos a la pantalla de Registro", Toast.LENGTH_SHORT).show();
                // Cuando crees la RegisterActivity, descomenta estas lineas:
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    // --- MÉTODOS DE AYUDA ---

    // Función que hace la magia de conectar con la nube
    private void iniciarSesionFirebase(String email, String password) {
        // Mostramos mensaje para saber que está pensando
        Toast.makeText(this, "Conectando...", Toast.LENGTH_SHORT).show();

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // ÉXITO: El usuario existe y la contraseña es correcta
                            Log.d("FIREBASE", "Login correcto");
                            irALaPrincipal();
                        } else {
                            // ERROR: Algo ha fallado (pass mal, usuario no existe, sin internet...)
                            Log.w("FIREBASE", "Error en login", task.getException());

                            // Mostramos el error exacto en pantalla (en inglés normalmente)
                            String errorMensaje = task.getException().getMessage();
                            Toast.makeText(LoginActivity.this, "Error: " + errorMensaje, Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    // Función para cambiar de pantalla
    private void irALaPrincipal() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish(); // Cierra el Login para que no se pueda volver atrás
    }

    // Esto comprueba si el usuario ya estaba logueado de antes al abrir la app
    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            irALaPrincipal();
        }
    }
}