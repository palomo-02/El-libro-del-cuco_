package com.example.ellibrodelcuco.interfaz_usuario.ACTIVITIES;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ellibrodelcuco.R;
import com.example.ellibrodelcuco.interfaz_usuario.ADAPTERS.ResenaAdapter;
import com.example.ellibrodelcuco.modelo.Libro;
import com.example.ellibrodelcuco.modelo.Resena;
import com.example.ellibrodelcuco.utils.LogrosHelper;
import com.example.ellibrodelcuco.utils.RachaHelper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DetalleLibroActivity extends AppCompatActivity {

    private ImageView ivPortada;
    private TextView tvTitulo, tvAutor, tvSinopsis, tvEstado, tvPorcentaje, tvMediaResenas;
    private Button btnPendiente, btnLeyendo, btnLeido, btnQuieroLeer, btnEliminar, btnRecomendar, btnGuardarProgreso;
    private ProgressBar pbProgreso;
    private EditText etPaginaActual;
    private RatingBar rbNuevaResena;
    private EditText etTextoResena;
    private Button btnPublicarResena;
    private RecyclerView rvResenas;
    private ResenaAdapter resenaAdapter;
    private List<Resena> listaResenas;

    private Libro libroActual;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_libro);

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        ivPortada = findViewById(R.id.ivDetallePortada);
        tvTitulo = findViewById(R.id.tvDetalleTitulo);
        tvAutor = findViewById(R.id.tvDetalleAutor);
        tvSinopsis = findViewById(R.id.tvDetalleSinopsis);
        tvEstado = findViewById(R.id.tvDetalleEstado);
        tvPorcentaje = findViewById(R.id.tvPorcentaje);
        tvMediaResenas = findViewById(R.id.tvMediaResenas);
        pbProgreso = findViewById(R.id.pbProgreso);
        etPaginaActual = findViewById(R.id.etPaginaActual);
        btnPendiente = findViewById(R.id.btnPendiente);
        btnLeyendo = findViewById(R.id.btnLeyendo);
        btnLeido = findViewById(R.id.btnLeido);
        btnQuieroLeer = findViewById(R.id.btnQuieroLeer);
        btnEliminar = findViewById(R.id.btnEliminar);
        btnRecomendar = findViewById(R.id.btnRecomendar);
        btnGuardarProgreso = findViewById(R.id.btnGuardarProgreso);
        rbNuevaResena = findViewById(R.id.rbNuevaResena);
        etTextoResena = findViewById(R.id.etTextoResena);
        btnPublicarResena = findViewById(R.id.btnPublicarResena);
        rvResenas = findViewById(R.id.rvResenas);

        listaResenas = new ArrayList<>();
        resenaAdapter = new ResenaAdapter(listaResenas);
        rvResenas.setLayoutManager(new LinearLayoutManager(this));
        rvResenas.setAdapter(resenaAdapter);
        rvResenas.setNestedScrollingEnabled(false);

        if (getIntent().hasExtra("libro")) {
            libroActual = (Libro) getIntent().getSerializableExtra("libro");
            cargarDatosEnPantalla();
            cargarDatosFirestore();
            cargarResenas();
        } else {
            Toast.makeText(this, "Error al cargar el libro", Toast.LENGTH_SHORT).show();
            finish();
        }

        btnPendiente.setOnClickListener(v -> actualizarEstado("Pendiente"));
        btnLeyendo.setOnClickListener(v -> actualizarEstado("Leyendo"));
        btnLeido.setOnClickListener(v -> actualizarEstado("Leído"));
        btnQuieroLeer.setOnClickListener(v -> actualizarEstado("Quiero leer"));
        btnEliminar.setOnClickListener(v -> borrarLibro());
        btnRecomendar.setOnClickListener(v -> mostrarDialogoRecomendar());
        btnGuardarProgreso.setOnClickListener(v -> guardarProgreso());
        btnPublicarResena.setOnClickListener(v -> publicarResena());
    }

    private void cargarDatosEnPantalla() {
        tvTitulo.setText(libroActual.getTitulo());
        tvAutor.setText(libroActual.getAutor());
        tvSinopsis.setText(libroActual.getSinopsis());
        tvEstado.setText("ESTADO: " + (libroActual.getEstado() != null ? libroActual.getEstado().toUpperCase() : ""));

        if (libroActual.getPortadaUrl() != null && !libroActual.getPortadaUrl().isEmpty()) {
            String url = libroActual.getPortadaUrl().replace("http:", "https:");
            Picasso.get().load(url).into(ivPortada);
        } else {
            ivPortada.setImageResource(R.drawable.logo);
        }

        actualizarProgressBar(libroActual.getPaginaActual(), libroActual.getTotalPaginas());
        if (libroActual.getPaginaActual() > 0) {
            etPaginaActual.setText(String.valueOf(libroActual.getPaginaActual()));
        }
    }

    private void cargarDatosFirestore() {
        if (mAuth.getCurrentUser() == null) return;
        db.collection("usuarios")
            .document(mAuth.getCurrentUser().getUid())
            .collection("biblioteca")
            .document(libroActual.getTitulo())
            .get()
            .addOnSuccessListener(doc -> {
                if (doc.exists()) {
                    Long pagActual = doc.getLong("paginaActual");
                    Long pagTotal = doc.getLong("totalPaginas");
                    if (pagActual != null) {
                        libroActual.setPaginaActual(pagActual.intValue());
                        etPaginaActual.setText(String.valueOf(pagActual));
                    }
                    if (pagTotal != null) {
                        libroActual.setTotalPaginas(pagTotal.intValue());
                    }
                    actualizarProgressBar(
                        pagActual != null ? pagActual.intValue() : 0,
                        pagTotal != null ? pagTotal.intValue() : 0
                    );
                }
            });
    }

    private void actualizarProgressBar(int pagActual, int pagTotal) {
        if (pagTotal > 0) {
            int porcentaje = pagActual * 100 / pagTotal;
            pbProgreso.setProgress(porcentaje);
            tvPorcentaje.setText(pagActual + " / " + pagTotal + " páginas (" + porcentaje + "%)");
        } else {
            pbProgreso.setProgress(0);
            tvPorcentaje.setText("Sin información de páginas");
        }
    }

    private void guardarProgreso() {
        if (mAuth.getCurrentUser() == null) return;
        String texto = etPaginaActual.getText().toString().trim();
        if (TextUtils.isEmpty(texto)) return;

        int nuevaPagina = Integer.parseInt(texto);
        Map<String, Object> update = new HashMap<>();
        update.put("paginaActual", nuevaPagina);
        db.collection("usuarios")
            .document(mAuth.getCurrentUser().getUid())
            .collection("biblioteca")
            .document(libroActual.getTitulo())
            .update(update)
            .addOnSuccessListener(aVoid -> {
                libroActual.setPaginaActual(nuevaPagina);
                actualizarProgressBar(nuevaPagina, libroActual.getTotalPaginas());
                Toast.makeText(this, "Progreso guardado", Toast.LENGTH_SHORT).show();
            });
    }

    private void actualizarEstado(String nuevoEstado) {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();

        Map<String, Object> update = new HashMap<>();
        update.put("estado", nuevoEstado);
        if ("Leído".equalsIgnoreCase(nuevoEstado)) {
            update.put("fechaLeido", FieldValue.serverTimestamp());
        }

        db.collection("usuarios")
            .document(uid)
            .collection("biblioteca")
            .document(libroActual.getTitulo())
            .update(update)
            .addOnSuccessListener(aVoid -> {
                Toast.makeText(this, "Libro movido a " + nuevoEstado, Toast.LENGTH_SHORT).show();
                tvEstado.setText("ESTADO: " + nuevoEstado.toUpperCase());
                RachaHelper.actualizarRacha(uid, db);
                LogrosHelper.comprobar(uid, db, this);
            });
    }

    private void borrarLibro() {
        if (mAuth.getCurrentUser() == null) return;
        db.collection("usuarios")
            .document(mAuth.getCurrentUser().getUid())
            .collection("biblioteca")
            .document(libroActual.getTitulo())
            .delete()
            .addOnSuccessListener(aVoid -> {
                Toast.makeText(this, "Libro eliminado", Toast.LENGTH_SHORT).show();
                finish();
            });
    }

    private void mostrarDialogoRecomendar() {
        new AlertDialog.Builder(this)
            .setTitle("Recomendar libro")
            .setItems(new String[]{"Compartir externamente", "Cancelar"}, (dialog, which) -> {
                if (which == 0) {
                    String mensaje = "Te recomiendo '" + libroActual.getTitulo() + "' de " +
                        libroActual.getAutor() + " — descárgalo en El Libro del Cuco";
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_TEXT, mensaje);
                    startActivity(Intent.createChooser(intent, "Compartir con..."));
                }
            })
            .show();
    }

    private void cargarResenas() {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();
        db.collection("usuarios")
            .document(uid)
            .collection("biblioteca")
            .document(libroActual.getTitulo())
            .collection("resenas")
            .addSnapshotListener((value, error) -> {
                if (value != null) {
                    listaResenas.clear();
                    float sumaNotas = 0;
                    for (QueryDocumentSnapshot doc : value) {
                        Resena r = doc.toObject(Resena.class);
                        listaResenas.add(r);
                        sumaNotas += r.getNota();
                    }
                    resenaAdapter.notifyDataSetChanged();
                    int total = listaResenas.size();
                    if (total > 0) {
                        float media = sumaNotas / total;
                        tvMediaResenas.setText(String.format("⭐ %.1f (%d reseña%s)", media, total, total == 1 ? "" : "s"));
                    } else {
                        tvMediaResenas.setText("Sin valoraciones aún");
                    }
                }
            });
    }

    private void publicarResena() {
        if (mAuth.getCurrentUser() == null) return;
        FirebaseUser user = mAuth.getCurrentUser();
        String texto = etTextoResena.getText().toString().trim();
        float nota = rbNuevaResena.getRating();
        if (TextUtils.isEmpty(texto) || nota == 0) {
            Toast.makeText(this, "Añade una valoración y texto", Toast.LENGTH_SHORT).show();
            return;
        }
        String nombre = user.getDisplayName() != null && !user.getDisplayName().isEmpty()
            ? user.getDisplayName() : "Lector Cuco";
        Resena resena = new Resena(user.getUid(), nombre, texto, nota, new Date());

        db.collection("usuarios")
            .document(user.getUid())
            .collection("biblioteca")
            .document(libroActual.getTitulo())
            .collection("resenas")
            .document(user.getUid())
            .set(resena)
            .addOnSuccessListener(aVoid -> {
                Toast.makeText(this, "Reseña publicada", Toast.LENGTH_SHORT).show();
                etTextoResena.setText("");
                rbNuevaResena.setRating(0);
                LogrosHelper.comprobarResena(user.getUid(), db, this);
            });
    }
}
